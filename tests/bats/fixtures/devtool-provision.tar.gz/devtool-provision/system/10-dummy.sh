#!/usr/bin/env bash
echo dummy-system
