#!/usr/bin/env bash
echo dummy-user
